from .generator import main

__all__ = ["main"]
